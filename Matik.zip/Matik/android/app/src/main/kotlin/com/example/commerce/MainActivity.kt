package com.example.commerce

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
