package com.example.matik

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
